# optimising-businessProcess-with-LLM
This project uses Azure OpenAI LLM models to enhance the existing business solutions.
